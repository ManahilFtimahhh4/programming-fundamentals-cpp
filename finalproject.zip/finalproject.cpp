#include <iostream>
#include <string>
#include <stdlib.h>
#include <conio.h>
#include <fstream>
using namespace std;

const int MAX_USERS = 100;
const int MAX_SERVICES = 11;

struct User {
    string name;
    string city;
    int cnic;
    string date;
    int selectedServices[4];
    bool filled = false;
};

User users[MAX_USERS];
int userCount = 0;

// Function declarations
void header();
void clearScreen();
void displayServices();
void registerUser();
void showAllRecords();
void ownermenu();
void usermenu();
void editservices();
void displayServicess(User &user);
void submitFeedback();
void viewAllFeedback();
void viewServiceGuideForUser();
void viewServiceGuideForOwner();

int main() {
    while (true) {
        string role;
        header();
        cout << "Enter your role (OWNER / USER): ";
        cin >> role;
        clearScreen();

        if (role == "OWNER") {
            while (true) {
                ownermenu();
                int option;
                cin >> option;
                clearScreen();

                if (option == 1)
                    viewServiceGuideForOwner();
                else if (option == 2)
                    showAllRecords();
                else if (option == 3)
                    viewAllFeedback();  // ADMIN sees feedback here
                else if (option == 4)
                    editservices();
                else if (option == 5) {
                    cout << "Exiting program. Goodbye!" << endl;
                    break;
                } else
                    cout << "Invalid option. Try again." << endl;

                cout << "\nPress any key to return to the main menu..." << endl;
                getch();
                clearScreen();
            }
        } else if (role == "USER") {
            while (true) {
                usermenu(); // show user options
                int choice;
                cin >> choice;
                clearScreen();

                if (choice == 1)
                    registerUser();
                else if (choice == 2)
                    viewServiceGuideForUser();
                else if (choice == 3)
                    submitFeedback(); // USER writes feedback
                else if (choice == 4) {
                    cout << "Thanks for visiting!\n";
                    break;
                } else {
                    cout << "Invalid choice.\n";
                }

                cout << "\nPress any key to return to the user menu..." << endl;
                getch();
                clearScreen();
            }
        } else {
            cout << "Invalid role. Try again.\n";
            getch();
            clearScreen();
        }
    }
}

// Display a simple header
void header() {
    cout << "###########################################################" << endl;
    cout << "##           COMMUNITY DEVELOPMENT INITIATIVES           ##" << endl;
    cout << "###########################################################\n"
         << endl;
}

// Clear screen
void clearScreen() {
    cout << "\nPress any key to continue..." << endl;
    cin.ignore();
    cin.get();
    system("cls");
}

// Owner menu
void ownermenu() {
    header();
    cout << "1. HAVE A PROGRAM GUIDE" << endl;
    cout << "2. Show All Records" << endl;
    cout << "3. View Feedback from Beneficiaries" << endl;
    cout << "4. Edit Services" << endl;
    cout << "5. Exit" << endl;
    cout << "Enter your choice: ";
}

// View available services
void displayServices() {
    fstream file;
    file.open("services.txt", ios::in);

    if (!file) {
        cout << "Error: Could not open services.txt\n";
        return;
    }

    string line;
    int id = 1;

    cout << "\n===== SERVICES OFFERED BY OUR FORAM =====\n\n";

    while (getline(file, line)) {
        cout << id << ". " << line << endl;
        id++;
    }

    cout << "\n=========================================\n";
    file.close();
}

// Allow admin to overwrite services
void editservices() {
    fstream file;
    file.open("services.txt", ios::out);

    if (!file) {
        cout << "Error: could not open services.txt\n";
        return;
    }

    cin.ignore();
    cout << "Enter new services (type END to stop):\n";

    string line;
    while (true) {
        getline(cin, line);
        if (line == "END")
            break;
        file << line << endl;
    }

    file.close();
    cout << " Services updated successfully.\n";
}

// Register user & select services
void registerUser() {
    if (userCount >= MAX_USERS) {
        cout << "Maximum user limit reached." << endl;
        return;
    }

    cin.ignore();
    User &user = users[userCount];

    cout << "Enter your name: ";
    getline(cin, user.name);

    cout << "Enter your city: ";
    getline(cin, user.city);

    cout << "Enter your CNIC: ";
    cin >> user.cnic;
    cin.ignore();

    cout << "Enter registration date: ";
    getline(cin, user.date);

    displayServices();
    displayServicess(user);

    user.filled = true;
    userCount++;

    cout << "\n User registered and services selected successfully!\n";
}

// Let user choose 4 services
void displayServicess(User &user) {
    cout << "\nSelect up to 4 services by their ID (1-" << MAX_SERVICES << "):\n";
    for (int i = 0; i < 4; i++) {
        cout << "Choice #" << i + 1 << ": ";
        cin >> user.selectedServices[i];
    }
}

// Admin sees all user records
void showAllRecords() {
    string services[MAX_SERVICES + 1];
    ifstream file("services.txt");
    string line;
    int index = 1;
    while (getline(file, line) && index <= MAX_SERVICES) {
        services[index++] = line;
    }
    file.close();

    header();
    cout << "--- All User Records ---\n\n";
    for (int i = 0; i < userCount; ++i) {
        if (!users[i].filled)
            continue;

        const User &user = users[i];
        cout << i + 1 << ". " << user.name << " | " << user.city
             << " | CNIC: " << user.cnic << " | Date: " << user.date << "\n";
        cout << "   Services:\n";

        for (int j = 0; j < 4; j++) {
            int sid = user.selectedServices[j];
            if (sid >= 1 && sid <= MAX_SERVICES)
                cout << "   " << (j + 1) << ". " << services[sid] << " | ID: " << sid << "\n";
            else
                cout << "   " << (j + 1) << ". Invalid Service ID: " << sid << "\n";
        }

        cout << "--------------------------------------\n";
    }
}

// ✅ User writes feedback and it is stored in feedback.txt
void submitFeedback() {
    cin.ignore();
    string name, message;

    cout << "Enter your name: ";
    getline(cin, name);

    cout << "Enter your feedback: ";
    getline(cin, message);

    ofstream file("feedback.txt", ios::app); // Append mode
    if (!file) {
        cout << "Error: Could not open feedback.txt\n";
        return;
    }

    file << "From: " << name << endl;
    file << "Feedback: " << message << endl;
    file << "------------------------\n";
    file.close();

    cout << "\nThank you! Your feedback has been recorded.\n";
}

// ✅ Admin views all feedback written by users
void viewAllFeedback() {
    ifstream file("feedback.txt");
    if (!file) {
        cout << "No feedback available yet.\n";
        return;
    }

    cout << "\n=== All Feedback from Beneficiaries ===\n\n";
    string line;
    while (getline(file, line)) {
        cout << line << endl;
    }
    file.close();
    cout << "\n=======================================\n";
}

// Show a guide for users
void viewServiceGuideForUser() {
    fstream file;
    file.open("user_guide.txt", ios::in);  // Open file for reading
    if (!file.is_open()) {
        cout << "Unable to open user guide file.\n";
        return;
    }

    cout << "\n----- USER SERVICE GUIDE -----\n";
    string line;
    while (getline(file, line)) {
        cout << line << endl;
    }

    file.close();
}

// Menu shown to user
void usermenu() {
    header();
    cout << "1. Register & Select Services\n";
    cout << "2. View User Guide\n";
    cout << "3. Submit Feedback\n";
    cout << "4. Exit\n";
    cout << "Enter your choice: ";
}
// show guide for admin
void viewServiceGuideForOwner() {
    fstream file;
    file.open("owner_guide.txt", ios::in);  // Open file for reading
    if (!file.is_open()) {
        cout << "Unable to open owner guide file.\n";
        return;
    }

    cout << "\n----- OWNER SERVICE GUIDE -----\n";
    string line;
    while (getline(file, line)) {
        cout << line << endl;
    }

    file.close();
}
